extends CharacterBody2D

var lifespan = 240

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta * 0.7


	lifespan -= 1
	if lifespan < 1:
		self.queue_free()
	
	move_and_slide()
