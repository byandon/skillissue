extends RigidBody2D

var isGravChanged = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	if not gravity_scale == get_meta("gravity") * flags.gravityBlockGravity:
		gravity_scale = get_meta("gravity") * flags.gravityBlockGravity
	else:
		pass
