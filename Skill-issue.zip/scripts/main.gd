extends Node2D

var player = preload("res://scenes/player.tscn")
var level = preload("res://scenes/levels/level2.tscn")

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	var temp = player.instantiate()
	add_child(temp)
	temp = level.instantiate()
	add_child(temp)
	
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass
