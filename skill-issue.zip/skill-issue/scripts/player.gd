extends CharacterBody2D

#The player's sprite, here for color changing and animation purposes
@onready var anim: AnimatedSprite2D = $AnimatedSprite2D

#Speed and jump height
const SPEED = 150.0
const JUMP_VELOCITY = -225.0
const DASH_SPEED = 400.0

#Horizontal speed multiplier for walljumps and momentum
var speedMult = 1.0

#Whether or not the player can dash
var canDash = false

#How long the player can hold jump to jump higher
var jumpTime = 0
#A forgiveness window for jumping late
var coyote = 0
#How long the player's dash has left
var dashFrame = 0

func _physics_process(delta: float) -> void:
	#Checks if the player is dashing, that overrides this movement
	if dashFrame < 0:
	
		#Gravity, also handles coyote time
		if not is_on_floor():
			velocity += get_gravity() * delta * 0.5
			coyote -= 1
		else:
			coyote = 5
			canDash = true

		#Jump
		if Input.is_action_just_pressed("jump") and (is_on_floor() or coyote > 0 or is_on_wall()):
			velocity.y = JUMP_VELOCITY
			coyote = 1
			jumpTime = 10
			if is_on_wall_only():
				velocity += get_wall_normal() * SPEED * 0.8
				jumpTime = 2
				speedMult = 0.0
	
		#Makes your jump shorter if you don't hold
		if Input.is_action_just_released("jump"):
			if velocity.y < 0:
				velocity.y = 0

		#Horizontal movement
		var direction := Input.get_axis("left", "right")
		if direction and speedMult == 1:
			velocity.x = move_toward(velocity.x, direction * SPEED, SPEED / 10.0 * speedMult)
		else:
			velocity.x = move_toward(velocity.x, 0, SPEED / 10.0 * speedMult)
			
		#Checks for dash input
		if Input.is_action_just_pressed("dash") and canDash:
			var dash = Input.get_vector("left", "right", "up", "down")
			if dash != Vector2(0, 0):
				canDash = false
				dashFrame = 8
				velocity = dash * DASH_SPEED
				speedMult = 1
				

		speedMult = move_toward(speedMult, 1, 0.025)
		
	else:
		if dashFrame > 6:
			var dash = Input.get_vector("left", "right", "up", "down")
			velocity = dash * DASH_SPEED
		dashFrame -= 1
		if dashFrame == 0:
			velocity = velocity / 4.0
			
		if Input.is_action_just_pressed("jump") and (is_on_floor() or coyote > 0 or is_on_wall()):
			dashFrame = -1
			velocity.y = JUMP_VELOCITY
			coyote = 1
			jumpTime = 10
			if is_on_wall_only():
				velocity += get_wall_normal() * SPEED * 0.6
				jumpTime = 2
				speedMult = 0.0
		
	
	if canDash:
		anim.modulate = Color(1, 1, 1, 1)
	else:
		anim.modulate = Color(1, 1, 1, 0.4)
	move_and_slide()
