extends CharacterBody2D

#The player's throwable
var capsule = preload("res://scenes/throwable.tscn")

#Running particles
@onready var rundust: GPUParticles2D = $rundust
#Jumping particles
@onready var jumpdust: GPUParticles2D = $jumpdust

#The hitbox for said throwable
@onready var throwable_box: Area2D = $throwableBox
#The hitbox that kills the player on collision
@onready var damage_box: Area2D = $damageBox
#The hitbox that checks for checkpoints
@onready var checkpoint: Area2D = $checkpoint

#What gravity gravity blocks should have on respawn
var spawnGravity = 1.0

#A prototype dash trail
@onready var line: Line2D = $line

#The player's sprite, here for color changing and animation purposes
@onready var anim: AnimatedSprite2D = $AnimatedSprite2D

#Speed and jump height
const SPEED = 150.0
const JUMP_VELOCITY = -225.0
const DASH_SPEED = 400.0

#Horizontal speed multiplier for walljumps and momentum
var speedMult = 1.0

#The amount of time before the player can turn again
var noTurnFrames = 0

#Whether or not the player can dash
var canDash = false

#How long the player can hold jump to jump higher
var jumpTime = 0
#A forgiveness window for jumping late
var coyote = 0
#How long the player's dash has left
var dashFrame = 0
#Direction of dash as a vector
var dash = Vector2(0, 0)
#How long the player has been in the air for
var airFrames = 0

#The player's previous however many positions
var positions = []

func _physics_process(delta: float) -> void:
	
	dashFrame -= 1
	
	#Checks if the player is dashing, that overrides this movement
	if dashFrame < 0:
		
		#Gravity, also handles coyote time
		if not is_on_floor():
			velocity += get_gravity() * delta * 0.5
			coyote -= 1
			airFrames += 1
		else:
			coyote = 5
			canDash = true
			airFrames = 0
			noTurnFrames = 0

		#Jump
		if Input.is_action_just_pressed("jump") and (is_on_floor() or coyote > 0 or is_on_wall()):
			velocity.y = JUMP_VELOCITY
			coyote = 1
			jumpTime = 10
			if is_on_wall_only():
				velocity += get_wall_normal() * SPEED
				jumpTime = 2
				noTurnFrames = 25
			anim.scale = Vector2(0.3, 0.7)
			jumpdust.restart()
	
		#Makes your jump shorter if you don't hold
		if Input.is_action_just_released("jump"):
			if velocity.y < 0:
				velocity.y = 0

		#Horizontal movement
		var direction := Input.get_axis("left", "right")
		if direction and noTurnFrames < 1:
			velocity.x = move_toward(velocity.x, direction * SPEED, SPEED / 10.0)
			anim.play("walk")
		else:
			if noTurnFrames < 3:
				velocity.x = move_toward(velocity.x, 0, SPEED / 10.0)
				anim.play("idle")
				
		if not is_on_floor() and airFrames > 3:
			if velocity.y > 80:
				anim.play("fall")
			elif velocity.y < 0:
				anim.play("jump")
			else:
				anim.play("hover")
		
		if is_on_floor() and anim.animation == "walk":
			rundust.emitting = true
		else:
			rundust.emitting = false
			
		#Checks for dash input
		if Input.is_action_just_pressed("dash") and canDash:
			dash = Input.get_vector("left", "right", "up", "down")
			if dash != Vector2(0, 0):
				canDash = false
				dashFrame = 8
				velocity = dash * DASH_SPEED
				speedMult = 1
			else:
				if anim.flip_h: 
					dash = Vector2(-1.0, 0.0)
				elif !anim.flip_h: 
					dash = Vector2(1.0, 0.0)
				canDash = false
				dashFrame = 8
				velocity = dash * DASH_SPEED
				speedMult = 1
				

		speedMult = move_toward(speedMult, 1, 0.035)
		
	else:
		anim.play("jump")
		
		if dashFrame > 6:
			dash = Input.get_vector("left", "right", "up", "down")
			if dash != Vector2(0, 0):
				velocity = dash * DASH_SPEED
				
		anim.scale = (((abs(dash) + Vector2(0.5, 0.5)) * 0.5) + Vector2(0.5, 0.5)) / 2.0
		
		if dashFrame == 0:
			velocity = velocity / 4.0
			
		if Input.is_action_just_pressed("jump") and (is_on_floor() or coyote > 0 or is_on_wall()):
			dashFrame = -1
			if dash.y == 1.0:
				velocity.y = JUMP_VELOCITY * 1.2
			else:
				velocity.y = JUMP_VELOCITY
			coyote = 1
			jumpTime = 10
			if is_on_wall_only():
				velocity += get_wall_normal() * SPEED * 0.2
				jumpTime = 2
				noTurnFrames = 25
			
	if canDash:
		anim.modulate = Color(1, 1, 1, 1)
	else:
		anim.modulate = Color(0.5, 0, 1, 1)
		
	if velocity.x > 0:
		anim.flip_h = false
	elif velocity.x < 0:
		anim.flip_h = true
		
	if Input.is_action_just_pressed("throw"):
		var throw = capsule.instantiate()
		var temp
		if anim.flip_h: 
			temp = Vector2(-1.0, 1.0)
		elif !anim.flip_h: 
			temp = Vector2(1.0, 1.0)
		throw.velocity = ((Vector2(100.0, -250.0) * temp) + velocity) / 2.0
		throw.global_position = global_position
		get_parent().add_child(throw)
		
	noTurnFrames -= 1
	
	move_and_slide()
	
	positions.append(global_position)
	if len(positions) > 15:
		positions.remove_at(0)
		
	if dashFrame < 0:
		line.width = 5 + (dashFrame / 2.0)
		for i in len(positions):
			if dashFrame < -10:
				positions[i] = global_position
			else:
				positions[i] = (global_position + positions[i]) / 2.0
	else:
		line.width = 5.0
		
	line.points = positions
	line.global_position = Vector2(0, -4)
	
	if len(throwable_box.get_overlapping_bodies()) > 0:
		for i in throwable_box.get_overlapping_bodies():
			i.queue_free()
			canDash = true
			
	if len(checkpoint.get_overlapping_areas()) > 0:
		for i in checkpoint.get_overlapping_areas():
			if i.global_position != flags.spawnPoint:
				flags.spawnPoint = i.global_position
				spawnGravity = flags.gravityBlockGravity
				print("spawnpoint set")

	if is_on_floor():
		global_position += -abs(get_platform_velocity() / 60.0)
		#velocity += get_platform_velocity()

	if len(damage_box.get_overlapping_bodies()) > 0:
		noTurnFrames = 0
		canDash = false
		jumpTime = 0
		coyote = 0
		dashFrame = 0
		dash = Vector2(0, 0)
		positions = []
		global_position = flags.spawnPoint
		velocity = Vector2(0, 0)
		flags.gravityBlockGravity = spawnGravity
		flags.playerDied.emit()
		
	
	anim.scale = ((anim.scale * 3.0) + Vector2(0.5, 0.5)) / 4.0
	
	flags.playerPos = global_position
