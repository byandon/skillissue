extends Node2D

@onready var buildings: TileMapLayer = $TileMapLayer
@onready var frontbuildings: TileMapLayer = $TileMapLayer2

@onready var sky: ColorRect = $ColorRect

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	sky.material.set_shader_parameter("offset", flags.playerPos / 15.0)
	buildings.position = flags.playerPos / -1.02
	frontbuildings.position = flags.playerPos / -1.005
