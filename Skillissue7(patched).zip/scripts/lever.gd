extends Area2D

var entered = false
@onready var anim: AnimatedSprite2D = $AnimatedSprite2D

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	if len(get_overlapping_bodies()) > 0:
		if !entered:
			flags.gravityBlockGravity = -flags.gravityBlockGravity
			print("area entered")
			print(flags.gravityBlockGravity)
			entered = true
			
	else:
		entered = false
		
	if flags.gravityBlockGravity == 1.0:
		anim.play("off")
	else:
		anim.play("on")
