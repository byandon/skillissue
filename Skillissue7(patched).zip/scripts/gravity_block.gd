extends CharacterBody2D

var isGravChanged = false
var gravity_scale = 1.0
var spawnPoint
var gravityMult = 1.0

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	spawnPoint = global_position
	velocity = Vector2(0, 0)
	flags.playerDied.connect(_on_player_death)

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _physics_process(_delta: float) -> void:
	if not gravity_scale == get_meta("gravity") * flags.gravityBlockGravity:
		gravity_scale = get_meta("gravity") * flags.gravityBlockGravity
	else:
		pass

	velocity += get_gravity() * gravity_scale * _delta * gravityMult
	
	move_and_slide()
	
	gravityMult = 1.0
	
	for i in get_slide_collision_count():
		
		var collision = get_slide_collision(i)
		var collider = collision.get_collider()
	
		if collider is CharacterBody2D:
			gravityMult = 25.0
			pass
		#	collider.global_position += (velocity)

func _on_player_death():
	global_position = spawnPoint
	velocity = Vector2(0, 0)
