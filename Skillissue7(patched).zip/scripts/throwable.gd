extends CharacterBody2D

@onready var collider: CollisionShape2D = $collider
@onready var sprite: Sprite2D = $Sprite2D

var lifespan = 240

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta * 0.35

	if lifespan < 225:
		collider.disabled = false

	sprite.global_rotation += (abs(velocity.y / 240.0)) * (velocity.x / abs(velocity.x))


	lifespan -= 1
	if lifespan < 1:
		self.queue_free()
	
	move_and_slide()
