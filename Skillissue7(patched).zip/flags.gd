extends Node

#Emitted when the player dies
signal playerDied

#Where the player respawns
var spawnPoint = Vector2(0, 0)

#Where the player is
var playerPos = Vector2(0, 0)

#The gravity multiplier of gravity blocks
var gravityBlockGravity = 1.0


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass
